import pandas as pd
import numpy as np
from faker import Faker
from datetime import datetime, timedelta
import random
import os
current_directory = os.getcwd()

# Initialize Faker
fake = Faker('en_US')
Faker.seed(42)
np.random.seed(42)
random.seed(42)

# Configuration
num_records = 6820

# States & Cities
states_cities = {
    'Georgia': ['Atlanta', 'Augusta', 'Columbus'],
    'North Carolina': ['Charlotte', 'Raleigh', 'Greensboro', 'Durham'],
    'Florida': ['Miami', 'Tampa', 'Jacksonville'],
    'Virginia': ['Virginia Beach', 'Chesapeake', 'Arlington'],
    'Texas': ['Houston', 'San Antonio', 'Dallas']
}
states = list(states_cities.keys())
state_prob = [0.02, 0.06, 0.62, 0.10, 0.20]
assigned_states = np.random.choice(states, size=num_records, p=state_prob)
assigned_cities = [np.random.choice(states_cities[state]) for state in assigned_states]

# Departments & Jobtitles
departments = ['HR', 'IT', 'Sales', 'Marketing', 'Finance', 'Operations', 'Customer Service']
departments_prob = [0.04, 0.13, 0.19, 0.1, 0.08, 0.27, 0.19]
jobtitles = {
    'HR': ['HR Manager', 'HR Coordinator', 'Recruiter', 'HR Assistant'],
    'IT': ['IT Manager', 'Software Developer', 'System Administrator', 'IT Support Specialist'],
    'Sales': ['Sales Manager', 'Sales Consultant', 'Sales Specialist', 'Sales Representative'],
    'Marketing': ['Marketing Manager', 'SEO Specialist', 'Content Creator', 'Marketing Coordinator'],
    'Finance': ['Finance Manager', 'Accountant', 'Financial Analyst', 'Accounts Payable Specialist'],
    'Operations': ['Operations Manager', 'Operations Analyst', 'Logistics Coordinator', 'Inventory Specialist'],
    'Customer Service': ['Customer Service Manager', 'Customer Service Representative', 'Support Specialist', 'Help Desk Technician']
}
jobtitles_prob = {
    'HR': [0.03, 0.3, 0.47, 0.2],  # HR Manager, HR Coordinator, Recruiter, HR Assistant
    'IT': [0.02, 0.47, 0.2, 0.31],  # IT Manager, Software Developer, System Administrator, IT Support Specialist
    'Sales': [0.03, 0.25, 0.32, 0.4],  # Sales Manager, Sales Consultant, Sales Specialist, Sales Representative
    'Marketing': [0.04, 0.25, 0.41, 0.3],  # Marketing Manager, SEO Specialist, Content Creator, Marketing Coordinator
    'Finance': [0.03, 0.37, 0.4, 0.2],  # Finance Manager, Accountant, Financial Analyst, Accounts Payable Specialist
    'Operations': [0.02, 0.2, 0.4, 0.38],  # Operations Manager, Operations Analyst, Logistics Coordinator, Inventory Specialist
    'Customer Service': [0.04, 0.3, 0.38, 0.28]  # Customer Service Manager, Customer Service Representative, Support Specialist, Help Desk Technician
}

# Educations
educations = ['High School', "Bachelor", "Master", 'PhD']

education_mapping = {
    'HR Manager': ["Master", "PhD"],
    'HR Coordinator': ["Bachelor", "Master"],
    'Recruiter': ["High School", "Bachelor"],
    'HR Assistant': ["High School", "Bachelor"],
    'IT Manager': ["PhD", "Master"],
    'Software Developer': ["Bachelor", "Master"],
    'System Administrator': ["Bachelor", "Master"],
    'IT Support Specialist': ["High School", "Bachelor"],
    'Sales Manager': ["Master","PhD"],
    'Sales Consultant': ["Bachelor", "Master", "PhD"],
    'Sales Specialist': ["Bachelor", "Master", "PhD"],
    'Sales Representative': ["Bachelor"],
    'Marketing Manager': ["Bachelor", "Master","PhD"],
    'SEO Specialist': ["High School", "Bachelor"],
    'Content Creator': ["High School", "Bachelor"],
    'Marketing Coordinator': ["Bachelor"],
    'Finance Manager': ["Master", "PhD"],
    'Accountant': ["Bachelor"],
    'Financial Analyst': ["Bachelor", "Master", "PhD"],
    'Accounts Payable Specialist': ["Bachelor"],
    'Operations Manager': ["Bachelor", "Master"],
    'Operations Analyst': ["Bachelor", "Master"],
    'Logistics Coordinator': ["Bachelor"],
    'Inventory Specialist': ["High School", "Bachelor"],
    'Customer Service Manager': ["Bachelor", "Master", "PhD"],
    'Customer Service Representative': ["High School", "Bachelor"],
    'Support Specialist': ["High School", "Bachelor"],
    'Customer Success Manager': ["Bachelor", "Master", "PhD"],
    'Help Desk Technician': ["High School", "Bachelor"]
}

# Hiring Date
# Define custom probability weights for each year
year_weights = {
    2015: 5,   # 5% probability
    2016: 8,   # 8% probability
    2017: 17,   # 17% probability
    2018: 9,  # 9% probability
    2019: 10,  # 10% probability
    2020: 11,  # 11% probability
    2021: 5,  # 5% probability
    2022: 12,  # 12% probability
    2023: 14,  # 14% probability
    2024: 9   # 9% probability
}

# Generate a random date based on custom probabilities
def generate_custom_date(year_weights):
    year = random.choices(list(year_weights.keys()), weights=list(year_weights.values()))[0]
    month = random.randint(1, 12)
    day = random.randint(1, 28)  # Assuming all months have 28 days for simplicity
    return fake.date_time_between(start_date=datetime(year, 1, 1), end_date=datetime(year, 12, 31))

def generate_salary(department, job_title):
    salary_dict = {
            'HR': {
                'HR Manager': np.random.randint(60000, 90000),
                'HR Coordinator': np.random.randint(50000, 60000),
                'Recruiter': np.random.randint(50000, 70000),
                'HR Assistant': np.random.randint(50000, 60000)
            },
            'IT': {
                'IT Manager': np.random.randint(80000, 130000),
                'Software Developer': np.random.randint(70000, 95000),
                'System Administrator': np.random.randint(60000, 90000),
                'IT Support Specialist': np.random.randint(50000, 60000)
            },
            'Sales': {
                'Sales Manager': np.random.randint(70000, 120000),
                'Sales Consultant': np.random.randint(60000, 90000),
                'Sales Specialist': np.random.randint(50000, 80000),
                'Sales Representative': np.random.randint(50000, 70000)
            },
            'Marketing': {
                'Marketing Manager': np.random.randint(70000, 100000),
                'SEO Specialist': np.random.randint(50000, 80000),
                'Content Creator': np.random.randint(50000, 60000),
                'Marketing Coordinator': np.random.randint(50000, 70000)
            },
            'Finance': {
                'Finance Manager': np.random.randint(80000, 140000),
                'Accountant': np.random.randint(50000, 80000),
                'Financial Analyst': np.random.randint(60000, 90000),
                'Accounts Payable Specialist': np.random.randint(50000, 60000)
            },
            'Operations': {
                'Operations Manager': np.random.randint(70000, 100000),
                'Operations Analyst': np.random.randint(50000, 80000),
                'Logistics Coordinator': np.random.randint(50000, 60000),
                'Inventory Specialist': np.random.randint(50000, 60000)
            },
            'Customer Service': {
                'Customer Service Manager': np.random.randint(60000, 90000),
                'Customer Service Representative': np.random.randint(50000, 60000),
                'Support Specialist': np.random.randint(50000, 60000),
                'Help Desk Technician': np.random.randint(50000, 80000)
            }
        }
    return salary_dict[department][job_title]

# Generate the dataset
data = []

boy_names = ["Alexander", "Benjamin", "Carlos", "David", "Elias", "Francis", "George", "Hector", "Isaiah", "Jacob", "Khalid", "Liam", "Mateo", "Nathan", "Omar", "Patrick", "Quinn", "Rafael", "Samuel", "Thomas", "Ulysses", "Victor", "William", "Xander", "Yosef", "Zachary", "Ahmad", "Brian", "Christian", "Diego", "Ethan", "Felipe", "Giovanni", "Hussein", "Ibrahim", "John", "Kurt", "Luis", "Mohammed", "Noah", "Oscar", "Pablo", "Qasim", "Ruben", "Stefan", "Tariq", "Umar", "Vincent", "Wesley", "Xavier", "Yusuf", "Zane", "Andrew", "Boris", "Christopher", "Daniel", "Emilio", "Frederick", "Gustav", "Harun", "Ian", "Jose", "Kieran", "Leo", "Miguel", "Nicolas", "Oliver", "Paul", "Quinton", "Rashid", "Sebastian", "Timothy", "Usman", "Vladimir", "Walter", "Xavi", "Yasir", "Ziad", "Anthony", "Bruno", "Charles", "Dimitri", "Evan", "Ferdinand", "Gregory", "Hassan", "Igor", "Juan", "Kevin", "Lorenzo", "Matthias", "Neil", "Owen", "Pietro", "Quincy", "Roderick", "Samuel", "Theodore", "Ulrich", "Valentin", "Warren", "Xander", "Yannick", "Zeke", "Alfred", "Benedict", "Cedric", "Dominic", "Edward", "Fabian", "Gerard", "Hamza", "Isidore", "Julian", "Karl", "Luka", "Marius", "Nigel", "Otto", "Pierre", "Quirino", "Reynaldo", "Sergio", "Thiago", "Ugo", "Valerio", "Wayne", "Xenon", "Yohan", "Zoltan", "Arnold", "Blake", "Connor", "Dennis", "Edwin", "Francisco", "Graham", "Herbert", "Isaac", "Julio", "Kenan", "Leandro", "Marcelo", "Norman", "Orlando", "Philippe", "Quenton", "Richard", "Scott", "Tobias", "Ulises", "Vaughn", "Will", "Xander", "Yandel", "Zebulon", "Adrian", "Bradley", "Colin", "Derek", "Erik", "Fernando", "Griffin", "Hugo", "Ishmael", "Javier", "Kendrick", "Lucian", "Manuel", "Nelson", "Orin", "Preston", "Quade", "Roberto", "Sean", "Tyler", "Urijah", "Vasilis", "Winston", "Xerxes", "Yael", "Zane", "Albert", "Brandon", "Colton", "Darius", "Emmanuel", "Floyd", "Gustavo", "Hugo", "Iker", "Jeremiah", "Kyler", "Leonard", "Malik", "Nolan", "Oswald", "Presley", "Quaid", "Roland", "Santiago", "Trevor", "Usher", "Valter", "Weston", "Xylon", "Yago", "Zayd", "Arthur", "Bruce", "Craig", "Dwayne", "Elliott", "Frederik", "Gideon", "Henry", "Ivan", "Joaquin", "Kai", "Lennox", "Mateusz", "Norman", "Odin", "Philip", "Quinn", "Raymond", "Spencer", "Tristan", "Uri", "Valentin", "Warren", "Xander", "Yousef", "Zion", "Alberto", "Brody", "Cyrus", "Duncan", "Esteban", "Fabian", "Garrison", "Harold", "Isaiah", "Jonas", "Kristof", "Louis", "Miguel", "Nash", "Oscar", "Preston", "Quintin", "Ronald", "Stanley", "Tyrone", "Ulysses", "Viktor", "William", "Xander", "Yanni", "Zacharias", "Arnold", "Benedict", "Casper", "Desmond", "Elvis", "Freddie", "Gavin", "Hector", "Ignatius", "Jorge", "Konrad", "Lucas", "Mark", "Nathaniel", "Omar", "Pascal", "Quincy", "Rafael", "Saul", "Trenton", "Uriel", "Vance", "Walter", "Xanthos", "Yahir", "Zev", "Alex", "Blaze", "Colt", "Dominick", "Ethan", "Franco", "Garrett", "Hubert", "Ivo", "Jameson", "Kristian", "Liam", "Maximus", "Nicholas", "Owen", "Pablo", "Quinlan", "Robert", "Sterling", "Thaddeus", "Urias", "Vincent", "Wyatt", "Xavi", "Yusef", "Zach", "Alvin", "Brian", "Curtis", "Dorian", "Ezekiel", "Finn", "Gilbert", "Holden", "Ishmael", "Jeremy", "Kai", "Lionel", "Malcolm", "Noel", "Omar", "Paxton", "Quenton", "Ray", "Sebastian", "Theodore", "Uriah", "Vince", "Wayne", "Xander", "Yanni", "Zane", "Arthur", "Bennett", "Cameron", "Douglas", "Elijah", "Felipe", "Giles", "Harlan", "Isaac", "Jon", "Kian", "Lawrence", "Max", "Nathan", "Oliver", "Preston", "Quinton", "Reid", "Shane", "Travis", "Uriel", "Victor", "Wesley", "Xavier", "Yannick", "Zeke", "Abraham", "Blake", "Clifford", "Dennis", "Edgar", "Felix", "Grady", "Hiram", "Isaiah", "Jared", "Kevin", "Landon", "Mark", "Nico", "Orlando", "Peter", "Quade", "Ramon", "Steven", "Timothy", "Ulrich", "Vladimir", "Waylon", "Xander", "Yusuf", "Zander"]  
girl_names = ["Amelia", "Beatrice", "Catherine", "Diana", "Eleanor", "Fiona", "Gabriella", "Hannah", "Isabella", "Jessica", "Katherine", "Lily", "Maria", "Nadia", "Olivia", "Penelope", "Quinn", "Rose", "Sophia", "Tatiana", "Ursula", "Victoria", "Wendy", "Xena", "Yasmine", "Zara", "Abigail", "Bethany", "Charlotte", "Dorothy", "Emily", "Francesca", "Georgia", "Helena", "Iris", "Josephine", "Keira", "Lucy", "Madeline", "Naomi", "Ophelia", "Phoebe", "Rachel", "Samantha", "Teresa", "Uma", "Violet", "Willow", "Ximena", "Yara", "Zoe", "Aisha", "Brianna", "Camila", "Delilah", "Eliza", "Fatima", "Gemma", "Hazel", "Ingrid", "Jasmine", "Kayla", "Leah", "Maya", "Nina", "Octavia", "Paloma", "Rebekah", "Selena", "Talia", "Una", "Vanessa", "Willa", "Xenia", "Yelena", "Zelda", "Aaliyah", "Blanca", "Carmen", "Dahlia", "Elena", "Fernanda", "Gianna", "Holly", "Imani", "Juliana", "Karina", "Laila", "Mila", "Nina", "Oriana", "Petra", "Ramona", "Sofia", "Thea", "Ulyana", "Vivian", "Wren", "Xochitl", "Yvette", "Zara", "Anastasia", "Bianca", "Cecilia", "Daria", "Elsa", "Freya", "Greta", "Helene", "Isolde", "Jocelyn", "Kira", "Lena", "Margot", "Nadia", "Odessa", "Patricia", "Renata", "Serena", "Tanya", "Uliana", "Valeria", "Wanda", "Xia", "Yulia", "Zina", "Alice", "Bella", "Clara", "Daphne", "Eva", "Flora", "Grace", "Helga", "Iliana", "Jade", "Kiara", "Livia", "Martha", "Noelle", "Opal", "Portia", "Rosa", "Simone", "Thalia", "Ursula", "Veronica", "Winona", "Xandra", "Yasmin", "Zara", "Alessandra", "Bridget", "Celia", "Daniella", "Evelyn", "Frida", "Genevieve", "Hope", "Isabel", "Jacqueline", "Kamila", "Liliana", "Maisie", "Natalia", "Orla", "Priscilla", "Ruby", "Sasha", "Tamara", "Uliana", "Valentina", "Wilhelmina", "Xia", "Yolanda", "Zora", "Adele", "Blythe", "Celine", "Diana", "Esme", "Freya", "Giselle", "Honor", "Ivy", "June", "Katrina", "Luna", "Miranda", "Nina", "Odessa", "Pearl", "Raina", "Selene", "Tessa", "Uliana", "Victoria", "Willa", "Xanthe", "Yvonne", "Zella", "Aria", "Beatrice", "Callista", "Daria", "Elina", "Flora", "Giselle", "Hilda", "Ilaria", "Janet", "Kiana", "Liora", "Milena", "Nadia", "Olenka", "Petra", "Raina", "Sarai", "Tiana", "Ursula", "Viola", "Winifred", "Xiomara", "Yara", "Ziva", "Alba", "Blythe", "Claudia", "Daphne", "Elara", "Freya", "Greta", "Hanna", "Ilse", "Jasmin", "Kaia", "Livia", "Mona", "Nia", "Olena", "Priya", "Risa", "Sonia", "Tamsin", "Uliana", "Verena", "Willow", "Xyla", "Ysabel", "Zina", "Ayla", "Brynn", "Cassia", "Della", "Eleni", "Fiona", "Gaia", "Helena", "Irina", "Joelle", "Kiera", "Leia", "Melina", "Nadia", "Orla", "Phaedra", "Romy", "Saskia", "Taryn", "Una", "Verity", "Wren", "Xandra", "Yulia", "Zelda", "Anya", "Brielle", "Celeste", "Dina", "Elodie", "Freja", "Gwen", "Ivy", "Janelle", "Kara", "Lyra", "Mira", "Nadia", "Oona", "Pia", "Rhea", "Sibyl", "Tess", "Una", "Vera", "Wynne", "Xaviera", "Yvette", "Zoe", "Audra", "Bria", "Cleo", "Delta", "Esme", "Freya", "Greta", "Hattie", "Iliana", "Jess", "Katia", "Luna", "Malia", "Neva", "Oriana", "Polly", "Rhea", "Sierra", "Tessa", "Uma", "Vera", "Winsome", "Xenia", "Ysabelle", "Zosia", "Abigail", "Bridget", "Charlotte", "Daisy", "Eliza", "Flora", "Grace", "Hannah", "Ivy", "Jessamine", "Kit", "Lucia", "Mae", "Nina", "Ophelia", "Poppy", "Rosa", "Sophie", "Tilda", "Una", "Violet", "Willow", "Xanthe", "Yara", "Zoe", "Angela", "Brooke", "Claire", "Danielle", "Ella", "Faith", "Gillian", "Holly", "Ivy", "Joy", "Kira", "Lydia", "Maisy", "Nina", "Olivia", "Paige", "Rebecca", "Sara", "Tara", "Una", "Violet", "Willow", "Xena", "Yara", "Zoe", "Abby", "Bella", "Cara", "Daphne", "Eliza", "Fiona", "Grace", "Harper", "Isabel", "Jade", "Kayla", "Lena", "Maisie", "Nina", "Olivia", "Piper", "Quinn", "Ruby", "Sophia", "Talia", "Una", "Vera", "Wren", "Xena", "Yara", "Zoe", "Alice", "Blair", "Chloe", "Daisy", "Eva", "Freya", "Gemma", "Hannah", "Iris", "Jane", "Kate", "Leah", "Maisie", "Nina", "Olivia", "Poppy", "Quinn", "Rose", "Sophia", "Tara", "Una", "Violet", "Willow", "Xena", "Yara", "Zoe", "Alyssa", "Bella", "Cara", "Daisy", "Ella", "Fiona", "Grace", "Holly", "Isla", "Jane", "Kayla", "Lily", "Maisie", "Nina", "Olivia", "Paige", "Quinn", "Ruby", "Sophia", "Tara", "Una", "Vera", "Wren", "Xena", "Yara", "Zoe", "Amy", "Blake", "Cara", "Daisy", "Ella", "Fiona", "Grace", "Hannah", "Ivy", "Jane", "Kayla", "Lena", "Maisie", "Nina", "Olivia", "Poppy", "Quinn", "Ruby", "Sophia", "Tara", "Una", "Vera", "Willow", "Xena", "Yara", "Zoe", "Amanda", "Brooke", "Cara", "Daisy", "Ella", "Fiona", "Grace", "Hannah", "Ivy", "Jane", "Kate", "Lena", "Maisie", "Nina", "Olivia", "Piper", "Quinn", "Ruby", "Sophia", "Tara", "Una", "Violet", "Wren", "Xena", "Yara", "Zoe", "Alice", "Bella", "Cara", "Daisy", "Ella", "Fiona", "Grace", "Hannah", "Isla", "Jane", "Kay"]
last_names = ["Smith", "Johnson", "Williams", "Brown", "Jones", "Garcia", "Miller", "Davis", "Rodriguez", "Martinez", "Hernandez", "Lopez", "Gonzalez", "Wilson", "Anderson", "Thomas", "Taylor", "Moore", "Jackson", "Martin", "Lee", "Perez", "Thompson", "White", "Harris", "Sanchez", "Clark", "Ramirez", "Lewis", "Robinson", "Walker", "Young", "Allen", "King", "Wright", "Scott", "Torres", "Nguyen", "Hill", "Flores", "Green", "Adams", "Nelson", "Baker", "Hall", "Rivera", "Campbell", "Mitchell", "Carter", "Roberts", "Gomez", "Phillips", "Evans", "Turner", "Diaz", "Parker", "Cruz", "Edwards", "Collins", "Reyes", "Stewart", "Morris", "Morales", "Murphy", "Cook", "Rogers", "Gutierrez", "Ortiz", "Morgan", "Cooper", "Peterson", "Bailey", "Reed", "Kelly", "Howard", "Ramos", "Kim", "Cox", "Ward", "Richardson", "Watson", "Brooks", "Chavez", "Wood", "James", "Bennett", "Gray", "Mendoza", "Ruiz", "Hughes", "Price", "Alvarez", "Castillo", "Sanders", "Patel", "Myers", "Long", "Ross", "Foster", "Jimenez", "Powell", "Jenkins", "Perry", "Russell", "Sullivan", "Bell", "Coleman", "Butler", "Henderson", "Barnes", "Gonzales", "Fisher", "Vasquez", "Simmons", "Romero", "Jordan", "Patterson", "Alexander", "Hamilton", "Graham", "Reynolds", "Griffin", "Wallace", "Moreno", "West", "Cole", "Hayes", "Bryant", "Herrera", "Gibson", "Ellis", "Tran", "Medina", "Aguilar", "Stevens", "Murray", "Ford", "Castro", "Marshall", "Owens", "Harrison", "Fernandez", "Mcdonald", "Woods", "Washington", "Kennedy", "Wells", "Vargas", "Henry", "Chen", "Freeman", "Webb", "Tucker", "Guzman", "Burns", "Crawford", "Olson", "Simpson", "Porter", "Hunter", "Gordon", "Mendez", "Silva", "Shaw", "Snyder", "Mason", "Dixon", "Munoz", "Hunt", "Hicks", "Holmes", "Palmer", "Wagner", "Black", "Robertson", "Boyd", "Rose", "Stone", "Salazar", "Fox", "Warren", "Mills", "Meyer", "Rice", "Schmidt", "Garza", "Daniels", "Ferguson", "Nichols", "Stephens", "Soto", "Weaver", "Ryan", "Gardner", "Payne", "Grant", "Dunn", "Kelley", "Spencer", "Hawkins", "Arnold", "Pierce", "Vazquez", "Hansen", "Peters", "Santos", "Hart", "Bradley", "Knight", "Elliott", "Cunningham", "Duncan", "Armstrong", "Hudson", "Carroll", "Lane", "Riley", "Andrews", "Alvarado", "Ray", "Delgado", "Berry", "Perkins", "Hoffman", "Johnston", "Matthews", "Pena", "Richards", "Contreras", "Willis", "Carpenter", "Lawrence", "Sandoval", "Guerrero", "George", "Chapman", "Rios", "Estrada", "Ortega", "Watkins", "Greene", "Nunez", "Wheeler", "Valdez", "Harper", "Burke", "Larson", "Santiago", "Maldonado", "Morrison", "Franklin", "Carlson", "Austin", "Dominguez", "Carr", "Lawson", "Jacobs", "Obrien", "Lynch", "Singh", "Vega", "Bishop", "Montgomery", "Oliver", "Jensen", "Harvey", "Williamson", "Gilbert", "Dean", "Sims", "Espinoza", "Howell", "Li", "Wong", "Reid", "Hanson", "Le", "Mckinney", "Walters", "Fowler", "Moses", "Griffith", "Caldwell", "Lowe", "Jennings", "Barnett", "Graves", "Jimenez", "Horton", "Shelton", "Barrett", "Obrien", "Castro", "Sutton", "Gregory", "Mcguire", "Lucas", "Miles", "Craig", "Rodriquez", "Chambers", "Holt", "Lambert", "Fletcher", "Watts", "Bates", "Hale", "Rhodes", "Pena", "Beck", "Newman", "Haynes", "Mcdaniel", "Mendez", "Bush", "Vaughn", "Parks", "Dawson", "Santiago", "Norris", "Hardy", "Love", "Steele", "Curry", "Powers", "Schultz", "Barker", "Guzman", "Page", "Munoz", "Ball", "Keller", "Chandler", "Weber", "Leonard", "Walsh", "Lyons", "Ramsey", "Wolfe", "Schneider", "Mullins", "Benson", "Sharp", "Bowen", "Daniel", "Barber", "Cummings", "Hines", "Baldwin", "Griffith", "Valdez", "Hubbard", "Salazar", "Reeves", "Warner", "Stevenson", "Burgess", "Santos", "Tate", "Cross", "Garner", "Mann", "Mack", "Moss", "Thornton", "Dennis", "Mcgee", "Farmer", "Delgado", "Aguilar", "Vega", "Glover", "Manning", "Cohen", "Harmon", "Rodgers", "Robbins", "Newton", "Todd", "Blair", "Higgins", "Ingram", "Reese", "Cannon", "Strickland", "Townsend", "Potter", "Goodwin", "Walton", "Rowe", "Hampton", "Ortega", "Patton", "Swanson", "Joseph", "Francis", "Goodman", "Maldonado", "Yates", "Becker", "Erickson", "Hodges", "Rios", "Conner", "Adkins", "Webster", "Norman", "Malone", "Hammond", "Flowers", "Cobb", "Moody", "Quinn", "Blake", "Maxwell", "Pope", "Floyd", "Osborne", "Paul", "Mccarthy", "Guerrero", "Lindsey", "Estrada", "Sandoval", "Gibbs", "Tyler", "Gross", "Fitzgerald", "Stokes", "Doyle", "Sherman", "Saunders", "Wise", "Colon", "Gill", "Alvarado", "Greer", "Padilla", "Simon", "Waters", "Nunez", "Ballard", "Schwartz", "Mcbride", "Houston", "Christensen", "Klein", "Pratt", "Briggs", "Parsons", "Mclaughlin", "Zimmerman", "French", "Buchanan", "Moran", "Copeland", "Roy", "Pittman", "Brady", "Mccormick", "Holloway", "Brock", "Poole", "Frank", "Logan", "Owen", "Bass", "Marsh", "Drake", "Wong", "Jefferson", "Park", "Morton", "Abbott", "Sparks", "Patrick", "Norton", "Huff", "Clayton", "Massey", "Lloyd", "Figueroa", "Carson", "Bowers", "Roberson", "Barton", "Tran", "Lamb", "Harrington", "Casey", "Boone", "Cortez", "Clarke", "Mathis", "Singleton", "Wilkins", "Cain", "Bryan", "Underwood", "Hogan", "Mckenzie", "Collier", "Luna", "Phelps", "Mcguire", "Allison", "Bridges", "Wilkerson", "Nash", "Summers", "Atkins"]

def get_first_name(gender):
    if gender == "Male":
        return random.choice(boy_names)
    elif gender == "Female":
        return random.choice(girl_names)
    else:
        raise ValueError("Gender must be 'Male' or 'Female'")
    
def generate_custom_date(year_weights):
    # Simulate date generation based on year_weights logic
    # For example:
    year = random.choices(list(year_weights.keys()), weights=year_weights.values())[0]
    month = random.randint(1, 12)
    day = random.randint(1, 28)  # Simplification; consider month length in production
    
    # Create a date object
    hiredate = datetime(year, month, day)

    return hiredate

# Define the maximum date
max_hire_date = datetime(2024, 4, 30)

for _ in range(num_records):
    employee_id = f"US-{random.randint(10000000, 99999999)}"
    last_name = random.choice(last_names)
    gender = np.random.choice(['Female', 'Male'], p=[0.52, 0.48])

    # assign first name based off of gender
    first_name = get_first_name(gender)

    state = np.random.choice(states, p=state_prob)
    city = np.random.choice(states_cities[state])
    # Generate the hiredate
    hiredate = generate_custom_date(year_weights)

    # Ensure the hiredate is no later than the max_hire_date
    if hiredate > max_hire_date:
        hiredate = max_hire_date
      #termdate
    department = np.random.choice(departments, p=departments_prob)
    job_title  = np.random.choice(jobtitles[department], p=jobtitles_prob[department])
    education_level = np.random.choice(education_mapping[job_title])
    performance_rating = np.random.choice(['Excellent', 'Good', 'Satisfactory', 'Needs Improvement'], p=[0.12, 0.5, 0.3, 0.08])
    salary = generate_salary(department, job_title)

    data.append([
        employee_id,
        first_name,
        last_name,
        gender,
        state,
        city,
        education_level,
        hiredate,
        department,
        job_title,
        salary,
        performance_rating,
    ])

## Create DataFrame
columns = [
     'Employee_ID',
     'First Name',
     'Last Name',
     'Gender',
     'State',
     'City',
     'Education Level',
     'Hiredate',
     'Department',
     'Job Title',
     'Salary',
     'Performance Rating',
    ]


df = pd.DataFrame(data, columns=columns)

# Add Birthdate
def generate_birthdate(row):
    age_distribution = {
        'under_25': 0.14,
        '25_34': 0.20,
        '35_44': 0.4,
        '45_54': 0.20,
        'over_55': 0.06
    }
    age_groups = list(age_distribution.keys())
    age_probs = list(age_distribution.values())
    age_group = np.random.choice(age_groups, p=age_probs)

    if any('Manager' in title for title in row['Job Title']):
        age = np.random.randint(30, 65)
    elif row['Education Level'] == 'PhD':
        age = np.random.randint(27, 65)
    elif age_group == 'under_25':
         age = np.random.randint(20, 25)
    elif age_group == '25_34':
        age = np.random.randint(25, 35)
    elif age_group == '35_44':
        age = np.random.randint(35, 45)
    elif age_group == '45_54':
        age = np.random.randint(45, 55)
    else:
        age = np.random.randint(56, 65)

    birthdate = fake.date_of_birth(minimum_age=age, maximum_age=age)
    return birthdate

# Apply the function to generate birthdates
df['Birthdate'] = df.apply(generate_birthdate, axis=1)

# Terminations
# Define termination distribution
year_weights = {
    2015: 5,
    2016: 7,
    2017: 10,
    2018: 12,
    2019: 9,
    2020: 10,
    2021: 20,
    2022: 10,
    2023: 7,
    2024: 10
}

# Calculate the total number of terminated employees
total_employees = num_records
termination_percentage = 0.15  # 15%
total_terminated = int(total_employees * termination_percentage)

# Generate termination dates based on distribution
termination_dates = []
for year, weight in year_weights.items():
    num_terminations = int(total_terminated * (weight / 100))
    termination_dates.extend([year] * num_terminations)

# Randomly shuffle the termination dates
random.shuffle(termination_dates)

# Assign termination dates to terminated employees
terminated_indices = df.index[:total_terminated]
for i, year in enumerate(termination_dates[:total_terminated]):
    df.at[terminated_indices[i], 'Termdate'] = datetime(year, 1, 1) + timedelta(days=random.randint(0, 365))

# Assign None to termdate for employees who are not terminated
df['Termdate'] = df['Termdate'].where(df['Termdate'].notnull(), None)

# Ensure termdate is at least 6 months after hiredat
df['Termdate'] = df.apply(lambda row: row['Hiredate'] + timedelta(days=180) if row['Termdate'] and row['Termdate'] < row['Hiredate'] + timedelta(days=180) else row['Termdate'], axis=1)

education_multiplier = {
    'High School': {'Male': 1.05, 'Female': 1.0},
    "Bachelor": {'Male': 1.1, 'Female': 1.0},
    "Master": {'Male': 1.0, 'Female': 1.1},
    'PhD': {'Male': 1.05, 'Female': 1.2}
}

# Function to calculate age from birthdate
def calculate_age(birthdate):
    today = pd.Timestamp('today')
    age = today.year - birthdate.year - ((today.month, today.day) < (birthdate.month, birthdate.day))
    return age

# Function to calculate the adjusted salary
def calculate_adjusted_salary(row):
    base_salary = row['Salary']
    gender = row['Gender']
    education = row['Education Level']
    age = calculate_age(row['Birthdate'])

    # Apply education multiplier
    multiplier = education_multiplier.get(education, {}).get(gender, 1.0)
    adjusted_salary = base_salary * multiplier

    # Apply age increment (between 0.1% and 0.3% per year of age)
    age_increment = 1 + np.random.uniform(0.001, 0.003) * age
    adjusted_salary *= age_increment

    # Ensure the adjusted salary is not lower than the base salary
    adjusted_salary = max(adjusted_salary, base_salary)

    # Round the adjusted salary to the nearest integer
    return round(adjusted_salary)

# Apply the function to the DataFrame
df['Salary'] = df.apply(calculate_adjusted_salary, axis=1)

# Convert 'Hiredate' and 'Birthdate' to datetime
df['Hiredate'] = pd.to_datetime(df['Hiredate']).dt.date
df['Birthdate'] = pd.to_datetime(df['Birthdate']).dt.date
df['Termdate'] = pd.to_datetime(df['Termdate']).dt.date

# Save to CSV
filename = 'HumanResources_dirty.csv'
df.to_csv(filename, index=False)
print(f"Successfully exported {filename} to: {current_directory}")